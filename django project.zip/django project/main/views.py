from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'wel.html')
def contact(request):
    return render(request,'contact.html')
def about(request):
    return render(request,'about.html')
def login(request):
    if request.method=="POST":
        a=request.POST['uname']
        b=request.POST['password']
        print("Username=",a)
        print("password=",b)
    return render(request, 'login.html')
def form(request):
    if request.method=="POST":
        ad=request.POST['Name']
        ac=request.POST['Place']
        ca=request.POST['Phone']
        da=request.POST['Mail']
        ba=request.POST['Username']
        na=request.POST['Pass']
        print("name=",ad)
        print("place=",ac)
        print("phone=",ca)
        print("email=",da)
        print("username=",ba)
        print("password=",na)
    return render(request, 'form.html')
    

